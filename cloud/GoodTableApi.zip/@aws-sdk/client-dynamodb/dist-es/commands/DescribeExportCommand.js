import { _ep6, _mw0, command } from "../commandBuilder";
import { DescribeExport$ } from "../schemas/schemas_0";
export class DescribeExportCommand extends command(_ep6, _mw0, "DescribeExport", DescribeExport$) {
}
