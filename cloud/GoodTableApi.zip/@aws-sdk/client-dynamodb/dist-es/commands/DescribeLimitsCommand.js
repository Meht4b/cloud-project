import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeLimits$ } from "../schemas/schemas_0";
export class DescribeLimitsCommand extends command(_ep0, _mw0, "DescribeLimits", DescribeLimits$) {
}
