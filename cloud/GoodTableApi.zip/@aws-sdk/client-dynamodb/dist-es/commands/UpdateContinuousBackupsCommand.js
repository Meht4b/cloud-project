import { _ep2, _mw0, command } from "../commandBuilder";
import { UpdateContinuousBackups$ } from "../schemas/schemas_0";
export class UpdateContinuousBackupsCommand extends command(_ep2, _mw0, "UpdateContinuousBackups", UpdateContinuousBackups$) {
}
