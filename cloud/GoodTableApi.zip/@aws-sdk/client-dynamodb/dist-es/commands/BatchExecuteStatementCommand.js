import { _ep0, _mw0, command } from "../commandBuilder";
import { BatchExecuteStatement$ } from "../schemas/schemas_0";
export class BatchExecuteStatementCommand extends command(_ep0, _mw0, "BatchExecuteStatement", BatchExecuteStatement$) {
}
