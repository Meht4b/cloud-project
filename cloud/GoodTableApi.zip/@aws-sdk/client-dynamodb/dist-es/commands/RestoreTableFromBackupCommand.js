import { _ep10, _mw0, command } from "../commandBuilder";
import { RestoreTableFromBackup$ } from "../schemas/schemas_0";
export class RestoreTableFromBackupCommand extends command(_ep10, _mw0, "RestoreTableFromBackup", RestoreTableFromBackup$) {
}
