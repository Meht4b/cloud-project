import { _ep2, _mw0, command } from "../commandBuilder";
import { Query$ } from "../schemas/schemas_0";
export class QueryCommand extends command(_ep2, _mw0, "Query", Query$) {
}
