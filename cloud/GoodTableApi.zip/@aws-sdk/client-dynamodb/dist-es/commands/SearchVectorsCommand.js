import { _ep11, _mw0, command } from "../commandBuilder";
import { SearchVectors$ } from "../schemas/schemas_0";
export class SearchVectorsCommand extends command(_ep11, _mw0, "SearchVectors", SearchVectors$) {
}
