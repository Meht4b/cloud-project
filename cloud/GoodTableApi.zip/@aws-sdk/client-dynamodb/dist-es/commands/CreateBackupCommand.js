import { _ep2, _mw0, command } from "../commandBuilder";
import { CreateBackup$ } from "../schemas/schemas_0";
export class CreateBackupCommand extends command(_ep2, _mw0, "CreateBackup", CreateBackup$) {
}
