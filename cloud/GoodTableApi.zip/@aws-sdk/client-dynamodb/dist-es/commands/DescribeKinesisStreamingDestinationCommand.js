import { _ep2, _mw0, command } from "../commandBuilder";
import { DescribeKinesisStreamingDestination$ } from "../schemas/schemas_0";
export class DescribeKinesisStreamingDestinationCommand extends command(_ep2, _mw0, "DescribeKinesisStreamingDestination", DescribeKinesisStreamingDestination$) {
}
