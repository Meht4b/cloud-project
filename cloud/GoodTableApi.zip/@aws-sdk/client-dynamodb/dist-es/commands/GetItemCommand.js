import { _ep2, _mw0, command } from "../commandBuilder";
import { GetItem$ } from "../schemas/schemas_0";
export class GetItemCommand extends command(_ep2, _mw0, "GetItem", GetItem$) {
}
