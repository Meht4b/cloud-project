import { _ep2, _mw0, command } from "../commandBuilder";
import { UpdateTable$ } from "../schemas/schemas_0";
export class UpdateTableCommand extends command(_ep2, _mw0, "UpdateTable", UpdateTable$) {
}
