import { _ep3, _mw0, command } from "../commandBuilder";
import { UpdateGlobalTable$ } from "../schemas/schemas_0";
export class UpdateGlobalTableCommand extends command(_ep3, _mw0, "UpdateGlobalTable", UpdateGlobalTable$) {
}
