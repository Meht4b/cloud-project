import { _ep10, _mw0, command } from "../commandBuilder";
import { RestoreTableToPointInTime$ } from "../schemas/schemas_0";
export class RestoreTableToPointInTimeCommand extends command(_ep10, _mw0, "RestoreTableToPointInTime", RestoreTableToPointInTime$) {
}
