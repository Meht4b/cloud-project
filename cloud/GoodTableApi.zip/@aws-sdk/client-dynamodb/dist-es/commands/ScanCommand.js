import { _ep2, _mw0, command } from "../commandBuilder";
import { Scan$ } from "../schemas/schemas_0";
export class ScanCommand extends command(_ep2, _mw0, "Scan", Scan$) {
}
