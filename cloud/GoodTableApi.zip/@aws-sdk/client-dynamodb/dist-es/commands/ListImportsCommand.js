import { _ep8, _mw0, command } from "../commandBuilder";
import { ListImports$ } from "../schemas/schemas_0";
export class ListImportsCommand extends command(_ep8, _mw0, "ListImports", ListImports$) {
}
