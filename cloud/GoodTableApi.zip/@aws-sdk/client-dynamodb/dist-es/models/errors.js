import { DynamoDBServiceException as __BaseException } from "./DynamoDBServiceException";
export class BackupInUseException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#BackupInUseException";
    name = "BackupInUseException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "BackupInUseException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, BackupInUseException.prototype);
    }
}
export class BackupNotFoundException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#BackupNotFoundException";
    name = "BackupNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "BackupNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, BackupNotFoundException.prototype);
    }
}
export class InternalServerError extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#InternalServerError";
    name = "InternalServerError";
    $fault = "server";
    constructor(opts) {
        super({
            name: "InternalServerError",
            $fault: "server",
            ...opts,
        });
        Object.setPrototypeOf(this, InternalServerError.prototype);
    }
}
export class RequestLimitExceeded extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#RequestLimitExceeded";
    name = "RequestLimitExceeded";
    $fault = "client";
    ThrottlingReasons;
    constructor(opts) {
        super({
            name: "RequestLimitExceeded",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, RequestLimitExceeded.prototype);
        this.ThrottlingReasons = opts.ThrottlingReasons;
    }
}
export class ThrottlingException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#ThrottlingException";
    name = "ThrottlingException";
    $fault = "client";
    throttlingReasons;
    constructor(opts) {
        super({
            name: "ThrottlingException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ThrottlingException.prototype);
        this.throttlingReasons = opts.throttlingReasons;
    }
}
export class InvalidEndpointException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#InvalidEndpointException";
    name = "InvalidEndpointException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidEndpointException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidEndpointException.prototype);
        this.Message = opts.Message;
    }
}
export class ProvisionedThroughputExceededException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#ProvisionedThroughputExceededException";
    name = "ProvisionedThroughputExceededException";
    $fault = "client";
    ThrottlingReasons;
    constructor(opts) {
        super({
            name: "ProvisionedThroughputExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ProvisionedThroughputExceededException.prototype);
        this.ThrottlingReasons = opts.ThrottlingReasons;
    }
}
export class ResourceNotFoundException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#ResourceNotFoundException";
    name = "ResourceNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ResourceNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceNotFoundException.prototype);
    }
}
export class ItemCollectionSizeLimitExceededException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#ItemCollectionSizeLimitExceededException";
    name = "ItemCollectionSizeLimitExceededException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ItemCollectionSizeLimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ItemCollectionSizeLimitExceededException.prototype);
    }
}
export class ReplicatedWriteConflictException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#ReplicatedWriteConflictException";
    name = "ReplicatedWriteConflictException";
    $fault = "client";
    $retryable = {};
    constructor(opts) {
        super({
            name: "ReplicatedWriteConflictException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ReplicatedWriteConflictException.prototype);
    }
}
export class ContinuousBackupsUnavailableException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#ContinuousBackupsUnavailableException";
    name = "ContinuousBackupsUnavailableException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ContinuousBackupsUnavailableException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ContinuousBackupsUnavailableException.prototype);
    }
}
export class LimitExceededException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#LimitExceededException";
    name = "LimitExceededException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "LimitExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, LimitExceededException.prototype);
    }
}
export class TableInUseException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#TableInUseException";
    name = "TableInUseException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "TableInUseException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TableInUseException.prototype);
    }
}
export class TableNotFoundException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#TableNotFoundException";
    name = "TableNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "TableNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TableNotFoundException.prototype);
    }
}
export class GlobalTableAlreadyExistsException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#GlobalTableAlreadyExistsException";
    name = "GlobalTableAlreadyExistsException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "GlobalTableAlreadyExistsException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, GlobalTableAlreadyExistsException.prototype);
    }
}
export class ResourceInUseException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#ResourceInUseException";
    name = "ResourceInUseException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ResourceInUseException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceInUseException.prototype);
    }
}
export class TransactionConflictException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#TransactionConflictException";
    name = "TransactionConflictException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "TransactionConflictException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TransactionConflictException.prototype);
    }
}
export class PolicyNotFoundException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#PolicyNotFoundException";
    name = "PolicyNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "PolicyNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, PolicyNotFoundException.prototype);
    }
}
export class ExportNotFoundException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#ExportNotFoundException";
    name = "ExportNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ExportNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ExportNotFoundException.prototype);
    }
}
export class GlobalTableNotFoundException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#GlobalTableNotFoundException";
    name = "GlobalTableNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "GlobalTableNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, GlobalTableNotFoundException.prototype);
    }
}
export class ImportNotFoundException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#ImportNotFoundException";
    name = "ImportNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ImportNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ImportNotFoundException.prototype);
    }
}
export class DuplicateItemException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#DuplicateItemException";
    name = "DuplicateItemException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "DuplicateItemException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, DuplicateItemException.prototype);
    }
}
export class IdempotentParameterMismatchException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#IdempotentParameterMismatchException";
    name = "IdempotentParameterMismatchException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "IdempotentParameterMismatchException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, IdempotentParameterMismatchException.prototype);
        this.Message = opts.Message;
    }
}
export class TransactionInProgressException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#TransactionInProgressException";
    name = "TransactionInProgressException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "TransactionInProgressException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TransactionInProgressException.prototype);
        this.Message = opts.Message;
    }
}
export class ExportConflictException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#ExportConflictException";
    name = "ExportConflictException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ExportConflictException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ExportConflictException.prototype);
    }
}
export class InvalidExportTimeException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#InvalidExportTimeException";
    name = "InvalidExportTimeException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidExportTimeException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidExportTimeException.prototype);
    }
}
export class PointInTimeRecoveryUnavailableException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#PointInTimeRecoveryUnavailableException";
    name = "PointInTimeRecoveryUnavailableException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "PointInTimeRecoveryUnavailableException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, PointInTimeRecoveryUnavailableException.prototype);
    }
}
export class ImportConflictException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#ImportConflictException";
    name = "ImportConflictException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ImportConflictException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ImportConflictException.prototype);
    }
}
export class TableAlreadyExistsException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#TableAlreadyExistsException";
    name = "TableAlreadyExistsException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "TableAlreadyExistsException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TableAlreadyExistsException.prototype);
    }
}
export class InvalidRestoreTimeException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#InvalidRestoreTimeException";
    name = "InvalidRestoreTimeException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "InvalidRestoreTimeException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidRestoreTimeException.prototype);
    }
}
export class ReplicaAlreadyExistsException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#ReplicaAlreadyExistsException";
    name = "ReplicaAlreadyExistsException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ReplicaAlreadyExistsException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ReplicaAlreadyExistsException.prototype);
    }
}
export class ReplicaNotFoundException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#ReplicaNotFoundException";
    name = "ReplicaNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "ReplicaNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ReplicaNotFoundException.prototype);
    }
}
export class IndexNotFoundException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#IndexNotFoundException";
    name = "IndexNotFoundException";
    $fault = "client";
    constructor(opts) {
        super({
            name: "IndexNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, IndexNotFoundException.prototype);
    }
}
export class ConditionalCheckFailedException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#ConditionalCheckFailedException";
    name = "ConditionalCheckFailedException";
    $fault = "client";
    Item;
    constructor(opts) {
        super({
            name: "ConditionalCheckFailedException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ConditionalCheckFailedException.prototype);
        this.Item = opts.Item;
    }
}
export class TransactionCanceledException extends __BaseException {
    static shapeId = "com.amazonaws.dynamodb#TransactionCanceledException";
    name = "TransactionCanceledException";
    $fault = "client";
    Message;
    CancellationReasons;
    constructor(opts) {
        super({
            name: "TransactionCanceledException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, TransactionCanceledException.prototype);
        this.Message = opts.Message;
        this.CancellationReasons = opts.CancellationReasons;
    }
}
