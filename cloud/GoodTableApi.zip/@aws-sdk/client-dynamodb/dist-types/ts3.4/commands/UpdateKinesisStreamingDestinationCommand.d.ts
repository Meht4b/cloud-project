import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  UpdateKinesisStreamingDestinationInput,
  UpdateKinesisStreamingDestinationOutput,
} from "../models/models_0";
export { __MetadataBearer };
export interface UpdateKinesisStreamingDestinationCommandInput extends UpdateKinesisStreamingDestinationInput {}
export interface UpdateKinesisStreamingDestinationCommandOutput
  extends UpdateKinesisStreamingDestinationOutput, __MetadataBearer {}
declare const UpdateKinesisStreamingDestinationCommand_base: {
  new (
    input: UpdateKinesisStreamingDestinationCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    UpdateKinesisStreamingDestinationCommandInput,
    UpdateKinesisStreamingDestinationCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: UpdateKinesisStreamingDestinationCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    UpdateKinesisStreamingDestinationCommandInput,
    UpdateKinesisStreamingDestinationCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class UpdateKinesisStreamingDestinationCommand extends UpdateKinesisStreamingDestinationCommand_base {
  protected static __types: {
    api: {
      input: UpdateKinesisStreamingDestinationInput;
      output: UpdateKinesisStreamingDestinationOutput;
    };
    sdk: {
      input: UpdateKinesisStreamingDestinationCommandInput;
      output: UpdateKinesisStreamingDestinationCommandOutput;
    };
  };
}
