import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { UpdateContinuousBackupsInput, UpdateContinuousBackupsOutput } from "../models/models_0";
export { __MetadataBearer };
export interface UpdateContinuousBackupsCommandInput extends UpdateContinuousBackupsInput {}
export interface UpdateContinuousBackupsCommandOutput
  extends UpdateContinuousBackupsOutput, __MetadataBearer {}
declare const UpdateContinuousBackupsCommand_base: {
  new (
    input: UpdateContinuousBackupsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    UpdateContinuousBackupsCommandInput,
    UpdateContinuousBackupsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: UpdateContinuousBackupsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    UpdateContinuousBackupsCommandInput,
    UpdateContinuousBackupsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class UpdateContinuousBackupsCommand extends UpdateContinuousBackupsCommand_base {
  protected static __types: {
    api: {
      input: UpdateContinuousBackupsInput;
      output: UpdateContinuousBackupsOutput;
    };
    sdk: {
      input: UpdateContinuousBackupsCommandInput;
      output: UpdateContinuousBackupsCommandOutput;
    };
  };
}
