import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { UntagResourceInput } from "../models/models_0";
export { __MetadataBearer };
export interface UntagResourceCommandInput extends UntagResourceInput {}
export interface UntagResourceCommandOutput extends __MetadataBearer {}
declare const UntagResourceCommand_base: {
  new (
    input: UntagResourceCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    UntagResourceCommandInput,
    UntagResourceCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: UntagResourceCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    UntagResourceCommandInput,
    UntagResourceCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class UntagResourceCommand extends UntagResourceCommand_base {
  protected static __types: {
    api: {
      input: UntagResourceInput;
      output: {};
    };
    sdk: {
      input: UntagResourceCommandInput;
      output: UntagResourceCommandOutput;
    };
  };
}
