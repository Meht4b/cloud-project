import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { ListBackupsInput, ListBackupsOutput } from "../models/models_0";
export { __MetadataBearer };
export interface ListBackupsCommandInput extends ListBackupsInput {}
export interface ListBackupsCommandOutput extends ListBackupsOutput, __MetadataBearer {}
declare const ListBackupsCommand_base: {
  new (
    input: ListBackupsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    ListBackupsCommandInput,
    ListBackupsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [ListBackupsCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    ListBackupsCommandInput,
    ListBackupsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class ListBackupsCommand extends ListBackupsCommand_base {
  protected static __types: {
    api: {
      input: ListBackupsInput;
      output: ListBackupsOutput;
    };
    sdk: {
      input: ListBackupsCommandInput;
      output: ListBackupsCommandOutput;
    };
  };
}
