import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  KinesisStreamingDestinationInput,
  KinesisStreamingDestinationOutput,
} from "../models/models_0";
export { __MetadataBearer };
export interface DisableKinesisStreamingDestinationCommandInput extends KinesisStreamingDestinationInput {}
export interface DisableKinesisStreamingDestinationCommandOutput
  extends KinesisStreamingDestinationOutput, __MetadataBearer {}
declare const DisableKinesisStreamingDestinationCommand_base: {
  new (
    input: DisableKinesisStreamingDestinationCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DisableKinesisStreamingDestinationCommandInput,
    DisableKinesisStreamingDestinationCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DisableKinesisStreamingDestinationCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DisableKinesisStreamingDestinationCommandInput,
    DisableKinesisStreamingDestinationCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DisableKinesisStreamingDestinationCommand extends DisableKinesisStreamingDestinationCommand_base {
  protected static __types: {
    api: {
      input: KinesisStreamingDestinationInput;
      output: KinesisStreamingDestinationOutput;
    };
    sdk: {
      input: DisableKinesisStreamingDestinationCommandInput;
      output: DisableKinesisStreamingDestinationCommandOutput;
    };
  };
}
