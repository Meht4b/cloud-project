import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { TransactGetItemsInput, TransactGetItemsOutput } from "../models/models_0";
export { __MetadataBearer };
export interface TransactGetItemsCommandInput extends TransactGetItemsInput {}
export interface TransactGetItemsCommandOutput extends TransactGetItemsOutput, __MetadataBearer {}
declare const TransactGetItemsCommand_base: {
  new (
    input: TransactGetItemsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    TransactGetItemsCommandInput,
    TransactGetItemsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: TransactGetItemsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    TransactGetItemsCommandInput,
    TransactGetItemsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class TransactGetItemsCommand extends TransactGetItemsCommand_base {
  protected static __types: {
    api: {
      input: TransactGetItemsInput;
      output: TransactGetItemsOutput;
    };
    sdk: {
      input: TransactGetItemsCommandInput;
      output: TransactGetItemsCommandOutput;
    };
  };
}
