import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  UpdateContributorInsightsInput,
  UpdateContributorInsightsOutput,
} from "../models/models_0";
export { __MetadataBearer };
export interface UpdateContributorInsightsCommandInput extends UpdateContributorInsightsInput {}
export interface UpdateContributorInsightsCommandOutput
  extends UpdateContributorInsightsOutput, __MetadataBearer {}
declare const UpdateContributorInsightsCommand_base: {
  new (
    input: UpdateContributorInsightsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    UpdateContributorInsightsCommandInput,
    UpdateContributorInsightsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: UpdateContributorInsightsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    UpdateContributorInsightsCommandInput,
    UpdateContributorInsightsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class UpdateContributorInsightsCommand extends UpdateContributorInsightsCommand_base {
  protected static __types: {
    api: {
      input: UpdateContributorInsightsInput;
      output: UpdateContributorInsightsOutput;
    };
    sdk: {
      input: UpdateContributorInsightsCommandInput;
      output: UpdateContributorInsightsCommandOutput;
    };
  };
}
