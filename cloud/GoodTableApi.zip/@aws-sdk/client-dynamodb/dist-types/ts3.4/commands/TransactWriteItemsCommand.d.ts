import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { TransactWriteItemsInput, TransactWriteItemsOutput } from "../models/models_0";
export { __MetadataBearer };
export interface TransactWriteItemsCommandInput extends TransactWriteItemsInput {}
export interface TransactWriteItemsCommandOutput
  extends TransactWriteItemsOutput, __MetadataBearer {}
declare const TransactWriteItemsCommand_base: {
  new (
    input: TransactWriteItemsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    TransactWriteItemsCommandInput,
    TransactWriteItemsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: TransactWriteItemsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    TransactWriteItemsCommandInput,
    TransactWriteItemsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class TransactWriteItemsCommand extends TransactWriteItemsCommand_base {
  protected static __types: {
    api: {
      input: TransactWriteItemsInput;
      output: TransactWriteItemsOutput;
    };
    sdk: {
      input: TransactWriteItemsCommandInput;
      output: TransactWriteItemsCommandOutput;
    };
  };
}
