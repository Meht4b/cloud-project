import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeGlobalTableSettingsInput,
  DescribeGlobalTableSettingsOutput,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeGlobalTableSettingsCommandInput extends DescribeGlobalTableSettingsInput {}
export interface DescribeGlobalTableSettingsCommandOutput
  extends DescribeGlobalTableSettingsOutput, __MetadataBearer {}
declare const DescribeGlobalTableSettingsCommand_base: {
  new (
    input: DescribeGlobalTableSettingsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeGlobalTableSettingsCommandInput,
    DescribeGlobalTableSettingsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeGlobalTableSettingsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeGlobalTableSettingsCommandInput,
    DescribeGlobalTableSettingsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeGlobalTableSettingsCommand extends DescribeGlobalTableSettingsCommand_base {
  protected static __types: {
    api: {
      input: DescribeGlobalTableSettingsInput;
      output: DescribeGlobalTableSettingsOutput;
    };
    sdk: {
      input: DescribeGlobalTableSettingsCommandInput;
      output: DescribeGlobalTableSettingsCommandOutput;
    };
  };
}
