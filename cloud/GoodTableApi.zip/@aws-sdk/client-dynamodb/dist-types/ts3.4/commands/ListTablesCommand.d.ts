import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { ListTablesInput, ListTablesOutput } from "../models/models_0";
export { __MetadataBearer };
export interface ListTablesCommandInput extends ListTablesInput {}
export interface ListTablesCommandOutput extends ListTablesOutput, __MetadataBearer {}
declare const ListTablesCommand_base: {
  new (
    input: ListTablesCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    ListTablesCommandInput,
    ListTablesCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [ListTablesCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    ListTablesCommandInput,
    ListTablesCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class ListTablesCommand extends ListTablesCommand_base {
  protected static __types: {
    api: {
      input: ListTablesInput;
      output: ListTablesOutput;
    };
    sdk: {
      input: ListTablesCommandInput;
      output: ListTablesCommandOutput;
    };
  };
}
