import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { TagResourceInput } from "../models/models_0";
export { __MetadataBearer };
export interface TagResourceCommandInput extends TagResourceInput {}
export interface TagResourceCommandOutput extends __MetadataBearer {}
declare const TagResourceCommand_base: {
  new (
    input: TagResourceCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    TagResourceCommandInput,
    TagResourceCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: TagResourceCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    TagResourceCommandInput,
    TagResourceCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class TagResourceCommand extends TagResourceCommand_base {
  protected static __types: {
    api: {
      input: TagResourceInput;
      output: {};
    };
    sdk: {
      input: TagResourceCommandInput;
      output: TagResourceCommandOutput;
    };
  };
}
