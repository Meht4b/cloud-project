import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { ListImportsInput, ListImportsOutput } from "../models/models_0";
export { __MetadataBearer };
export interface ListImportsCommandInput extends ListImportsInput {}
export interface ListImportsCommandOutput extends ListImportsOutput, __MetadataBearer {}
declare const ListImportsCommand_base: {
  new (
    input: ListImportsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    ListImportsCommandInput,
    ListImportsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [ListImportsCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    ListImportsCommandInput,
    ListImportsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class ListImportsCommand extends ListImportsCommand_base {
  protected static __types: {
    api: {
      input: ListImportsInput;
      output: ListImportsOutput;
    };
    sdk: {
      input: ListImportsCommandInput;
      output: ListImportsCommandOutput;
    };
  };
}
