import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DescribeEndpointsRequest, DescribeEndpointsResponse } from "../models/models_0";
export { __MetadataBearer };
export interface DescribeEndpointsCommandInput extends DescribeEndpointsRequest {}
export interface DescribeEndpointsCommandOutput
  extends DescribeEndpointsResponse, __MetadataBearer {}
declare const DescribeEndpointsCommand_base: {
  new (
    input: DescribeEndpointsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeEndpointsCommandInput,
    DescribeEndpointsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [DescribeEndpointsCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    DescribeEndpointsCommandInput,
    DescribeEndpointsCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeEndpointsCommand extends DescribeEndpointsCommand_base {
  protected static __types: {
    api: {
      input: {};
      output: DescribeEndpointsResponse;
    };
    sdk: {
      input: DescribeEndpointsCommandInput;
      output: DescribeEndpointsCommandOutput;
    };
  };
}
