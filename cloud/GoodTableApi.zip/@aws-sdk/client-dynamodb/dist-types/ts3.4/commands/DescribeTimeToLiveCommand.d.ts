import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DescribeTimeToLiveInput, DescribeTimeToLiveOutput } from "../models/models_0";
export { __MetadataBearer };
export interface DescribeTimeToLiveCommandInput extends DescribeTimeToLiveInput {}
export interface DescribeTimeToLiveCommandOutput
  extends DescribeTimeToLiveOutput, __MetadataBearer {}
declare const DescribeTimeToLiveCommand_base: {
  new (
    input: DescribeTimeToLiveCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeTimeToLiveCommandInput,
    DescribeTimeToLiveCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeTimeToLiveCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeTimeToLiveCommandInput,
    DescribeTimeToLiveCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeTimeToLiveCommand extends DescribeTimeToLiveCommand_base {
  protected static __types: {
    api: {
      input: DescribeTimeToLiveInput;
      output: DescribeTimeToLiveOutput;
    };
    sdk: {
      input: DescribeTimeToLiveCommandInput;
      output: DescribeTimeToLiveCommandOutput;
    };
  };
}
