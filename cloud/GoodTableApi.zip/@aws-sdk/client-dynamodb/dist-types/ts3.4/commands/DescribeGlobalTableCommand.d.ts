import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DescribeGlobalTableInput, DescribeGlobalTableOutput } from "../models/models_0";
export { __MetadataBearer };
export interface DescribeGlobalTableCommandInput extends DescribeGlobalTableInput {}
export interface DescribeGlobalTableCommandOutput
  extends DescribeGlobalTableOutput, __MetadataBearer {}
declare const DescribeGlobalTableCommand_base: {
  new (
    input: DescribeGlobalTableCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeGlobalTableCommandInput,
    DescribeGlobalTableCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeGlobalTableCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeGlobalTableCommandInput,
    DescribeGlobalTableCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeGlobalTableCommand extends DescribeGlobalTableCommand_base {
  protected static __types: {
    api: {
      input: DescribeGlobalTableInput;
      output: DescribeGlobalTableOutput;
    };
    sdk: {
      input: DescribeGlobalTableCommandInput;
      output: DescribeGlobalTableCommandOutput;
    };
  };
}
