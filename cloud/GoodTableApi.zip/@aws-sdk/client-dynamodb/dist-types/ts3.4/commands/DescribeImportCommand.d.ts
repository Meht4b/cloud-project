import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DescribeImportInput, DescribeImportOutput } from "../models/models_0";
export { __MetadataBearer };
export interface DescribeImportCommandInput extends DescribeImportInput {}
export interface DescribeImportCommandOutput extends DescribeImportOutput, __MetadataBearer {}
declare const DescribeImportCommand_base: {
  new (
    input: DescribeImportCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeImportCommandInput,
    DescribeImportCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeImportCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeImportCommandInput,
    DescribeImportCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeImportCommand extends DescribeImportCommand_base {
  protected static __types: {
    api: {
      input: DescribeImportInput;
      output: DescribeImportOutput;
    };
    sdk: {
      input: DescribeImportCommandInput;
      output: DescribeImportCommandOutput;
    };
  };
}
