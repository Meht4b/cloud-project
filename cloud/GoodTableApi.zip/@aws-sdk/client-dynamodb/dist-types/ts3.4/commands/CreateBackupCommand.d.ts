import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { CreateBackupInput, CreateBackupOutput } from "../models/models_0";
export { __MetadataBearer };
export interface CreateBackupCommandInput extends CreateBackupInput {}
export interface CreateBackupCommandOutput extends CreateBackupOutput, __MetadataBearer {}
declare const CreateBackupCommand_base: {
  new (
    input: CreateBackupCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CreateBackupCommandInput,
    CreateBackupCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: CreateBackupCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    CreateBackupCommandInput,
    CreateBackupCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class CreateBackupCommand extends CreateBackupCommand_base {
  protected static __types: {
    api: {
      input: CreateBackupInput;
      output: CreateBackupOutput;
    };
    sdk: {
      input: CreateBackupCommandInput;
      output: CreateBackupCommandOutput;
    };
  };
}
