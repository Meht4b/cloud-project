import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DescribeTableInput, DescribeTableOutput } from "../models/models_0";
export { __MetadataBearer };
export interface DescribeTableCommandInput extends DescribeTableInput {}
export interface DescribeTableCommandOutput extends DescribeTableOutput, __MetadataBearer {}
declare const DescribeTableCommand_base: {
  new (
    input: DescribeTableCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeTableCommandInput,
    DescribeTableCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeTableCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeTableCommandInput,
    DescribeTableCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeTableCommand extends DescribeTableCommand_base {
  protected static __types: {
    api: {
      input: DescribeTableInput;
      output: DescribeTableOutput;
    };
    sdk: {
      input: DescribeTableCommandInput;
      output: DescribeTableCommandOutput;
    };
  };
}
