import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  RestoreTableToPointInTimeInput,
  RestoreTableToPointInTimeOutput,
} from "../models/models_0";
export { __MetadataBearer };
export interface RestoreTableToPointInTimeCommandInput extends RestoreTableToPointInTimeInput {}
export interface RestoreTableToPointInTimeCommandOutput
  extends RestoreTableToPointInTimeOutput, __MetadataBearer {}
declare const RestoreTableToPointInTimeCommand_base: {
  new (
    input: RestoreTableToPointInTimeCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    RestoreTableToPointInTimeCommandInput,
    RestoreTableToPointInTimeCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: RestoreTableToPointInTimeCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    RestoreTableToPointInTimeCommandInput,
    RestoreTableToPointInTimeCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class RestoreTableToPointInTimeCommand extends RestoreTableToPointInTimeCommand_base {
  protected static __types: {
    api: {
      input: RestoreTableToPointInTimeInput;
      output: RestoreTableToPointInTimeOutput;
    };
    sdk: {
      input: RestoreTableToPointInTimeCommandInput;
      output: RestoreTableToPointInTimeCommandOutput;
    };
  };
}
