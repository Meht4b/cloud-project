import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  DescribeTableReplicaAutoScalingInput,
  DescribeTableReplicaAutoScalingOutput,
} from "../models/models_0";
export { __MetadataBearer };
export interface DescribeTableReplicaAutoScalingCommandInput extends DescribeTableReplicaAutoScalingInput {}
export interface DescribeTableReplicaAutoScalingCommandOutput
  extends DescribeTableReplicaAutoScalingOutput, __MetadataBearer {}
declare const DescribeTableReplicaAutoScalingCommand_base: {
  new (
    input: DescribeTableReplicaAutoScalingCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeTableReplicaAutoScalingCommandInput,
    DescribeTableReplicaAutoScalingCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: DescribeTableReplicaAutoScalingCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeTableReplicaAutoScalingCommandInput,
    DescribeTableReplicaAutoScalingCommandOutput,
    import("..").DynamoDBClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeTableReplicaAutoScalingCommand extends DescribeTableReplicaAutoScalingCommand_base {
  protected static __types: {
    api: {
      input: DescribeTableReplicaAutoScalingInput;
      output: DescribeTableReplicaAutoScalingOutput;
    };
    sdk: {
      input: DescribeTableReplicaAutoScalingCommandInput;
      output: DescribeTableReplicaAutoScalingCommandOutput;
    };
  };
}
