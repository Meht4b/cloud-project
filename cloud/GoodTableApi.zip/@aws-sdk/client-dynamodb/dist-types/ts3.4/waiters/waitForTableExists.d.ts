import { WaiterConfiguration, WaiterResult } from "@smithy/core/client";
import {
  DescribeTableCommandInput,
  DescribeTableCommandOutput,
} from "../commands/DescribeTableCommand";
import { DynamoDBClient } from "../DynamoDBClient";
import { DynamoDBServiceException } from "../models/DynamoDBServiceException";
export declare const waitForTableExists: (
  params: WaiterConfiguration<DynamoDBClient>,
  input: DescribeTableCommandInput,
) => Promise<WaiterResult<DescribeTableCommandOutput | DynamoDBServiceException>>;
export declare const waitUntilTableExists: (
  params: WaiterConfiguration<DynamoDBClient>,
  input: DescribeTableCommandInput,
) => Promise<WaiterResult<DescribeTableCommandOutput>>;
