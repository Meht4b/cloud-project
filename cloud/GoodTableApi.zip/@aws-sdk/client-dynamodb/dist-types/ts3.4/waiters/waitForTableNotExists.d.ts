import { WaiterConfiguration, WaiterResult } from "@smithy/core/client";
import {
  DescribeTableCommandInput,
  DescribeTableCommandOutput,
} from "../commands/DescribeTableCommand";
import { DynamoDBClient } from "../DynamoDBClient";
import { DynamoDBServiceException } from "../models/DynamoDBServiceException";
import { ResourceNotFoundException } from "../models/errors";
export declare const waitForTableNotExists: (
  params: WaiterConfiguration<DynamoDBClient>,
  input: DescribeTableCommandInput,
) => Promise<WaiterResult<DescribeTableCommandOutput | DynamoDBServiceException>>;
export declare const waitUntilTableNotExists: (
  params: WaiterConfiguration<DynamoDBClient>,
  input: DescribeTableCommandInput,
) => Promise<WaiterResult<ResourceNotFoundException>>;
