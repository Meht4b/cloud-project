import { WaiterConfiguration, WaiterResult } from "@smithy/core/client";
import {
  DescribeKinesisStreamingDestinationCommandInput,
  DescribeKinesisStreamingDestinationCommandOutput,
} from "../commands/DescribeKinesisStreamingDestinationCommand";
import { DynamoDBClient } from "../DynamoDBClient";
import { DynamoDBServiceException } from "../models/DynamoDBServiceException";
export declare const waitForKinesisStreamingDestinationActive: (
  params: WaiterConfiguration<DynamoDBClient>,
  input: DescribeKinesisStreamingDestinationCommandInput,
) => Promise<
  WaiterResult<DescribeKinesisStreamingDestinationCommandOutput | DynamoDBServiceException>
>;
export declare const waitUntilKinesisStreamingDestinationActive: (
  params: WaiterConfiguration<DynamoDBClient>,
  input: DescribeKinesisStreamingDestinationCommandInput,
) => Promise<WaiterResult<DescribeKinesisStreamingDestinationCommandOutput>>;
