import { WaiterConfiguration, WaiterResult } from "@smithy/core/client";
import {
  DescribeImportCommandInput,
  DescribeImportCommandOutput,
} from "../commands/DescribeImportCommand";
import { DynamoDBClient } from "../DynamoDBClient";
import { DynamoDBServiceException } from "../models/DynamoDBServiceException";
export declare const waitForImportCompleted: (
  params: WaiterConfiguration<DynamoDBClient>,
  input: DescribeImportCommandInput,
) => Promise<WaiterResult<DescribeImportCommandOutput | DynamoDBServiceException>>;
export declare const waitUntilImportCompleted: (
  params: WaiterConfiguration<DynamoDBClient>,
  input: DescribeImportCommandInput,
) => Promise<WaiterResult<DescribeImportCommandOutput>>;
