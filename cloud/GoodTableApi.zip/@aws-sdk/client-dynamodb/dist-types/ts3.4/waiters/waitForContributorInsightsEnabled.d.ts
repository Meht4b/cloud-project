import { WaiterConfiguration, WaiterResult } from "@smithy/core/client";
import {
  DescribeContributorInsightsCommandInput,
  DescribeContributorInsightsCommandOutput,
} from "../commands/DescribeContributorInsightsCommand";
import { DynamoDBClient } from "../DynamoDBClient";
import { DynamoDBServiceException } from "../models/DynamoDBServiceException";
export declare const waitForContributorInsightsEnabled: (
  params: WaiterConfiguration<DynamoDBClient>,
  input: DescribeContributorInsightsCommandInput,
) => Promise<WaiterResult<DescribeContributorInsightsCommandOutput | DynamoDBServiceException>>;
export declare const waitUntilContributorInsightsEnabled: (
  params: WaiterConfiguration<DynamoDBClient>,
  input: DescribeContributorInsightsCommandInput,
) => Promise<WaiterResult<DescribeContributorInsightsCommandOutput>>;
