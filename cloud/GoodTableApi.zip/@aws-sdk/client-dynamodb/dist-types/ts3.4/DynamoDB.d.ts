import { WaiterResult } from "@smithy/core/client";
import {
  HttpHandlerOptions as __HttpHandlerOptions,
  MetricsRecorder as __MetricsRecorder,
  PaginationConfiguration,
  Paginator,
  WaiterConfiguration,
} from "@smithy/types";
import {
  BatchExecuteStatementCommandInput,
  BatchExecuteStatementCommandOutput,
} from "./commands/BatchExecuteStatementCommand";
import {
  BatchGetItemCommandInput,
  BatchGetItemCommandOutput,
} from "./commands/BatchGetItemCommand";
import {
  BatchWriteItemCommandInput,
  BatchWriteItemCommandOutput,
} from "./commands/BatchWriteItemCommand";
import {
  CreateBackupCommandInput,
  CreateBackupCommandOutput,
} from "./commands/CreateBackupCommand";
import {
  CreateGlobalTableCommandInput,
  CreateGlobalTableCommandOutput,
} from "./commands/CreateGlobalTableCommand";
import { CreateTableCommandInput, CreateTableCommandOutput } from "./commands/CreateTableCommand";
import {
  DeleteBackupCommandInput,
  DeleteBackupCommandOutput,
} from "./commands/DeleteBackupCommand";
import { DeleteItemCommandInput, DeleteItemCommandOutput } from "./commands/DeleteItemCommand";
import {
  DeleteResourcePolicyCommandInput,
  DeleteResourcePolicyCommandOutput,
} from "./commands/DeleteResourcePolicyCommand";
import { DeleteTableCommandInput, DeleteTableCommandOutput } from "./commands/DeleteTableCommand";
import {
  DescribeBackupCommandInput,
  DescribeBackupCommandOutput,
} from "./commands/DescribeBackupCommand";
import {
  DescribeContinuousBackupsCommandInput,
  DescribeContinuousBackupsCommandOutput,
} from "./commands/DescribeContinuousBackupsCommand";
import {
  DescribeContributorInsightsCommandInput,
  DescribeContributorInsightsCommandOutput,
} from "./commands/DescribeContributorInsightsCommand";
import {
  DescribeEndpointsCommandInput,
  DescribeEndpointsCommandOutput,
} from "./commands/DescribeEndpointsCommand";
import {
  DescribeExportCommandInput,
  DescribeExportCommandOutput,
} from "./commands/DescribeExportCommand";
import {
  DescribeGlobalTableCommandInput,
  DescribeGlobalTableCommandOutput,
} from "./commands/DescribeGlobalTableCommand";
import {
  DescribeGlobalTableSettingsCommandInput,
  DescribeGlobalTableSettingsCommandOutput,
} from "./commands/DescribeGlobalTableSettingsCommand";
import {
  DescribeImportCommandInput,
  DescribeImportCommandOutput,
} from "./commands/DescribeImportCommand";
import {
  DescribeKinesisStreamingDestinationCommandInput,
  DescribeKinesisStreamingDestinationCommandOutput,
} from "./commands/DescribeKinesisStreamingDestinationCommand";
import {
  DescribeLimitsCommandInput,
  DescribeLimitsCommandOutput,
} from "./commands/DescribeLimitsCommand";
import {
  DescribeTableCommandInput,
  DescribeTableCommandOutput,
} from "./commands/DescribeTableCommand";
import {
  DescribeTableReplicaAutoScalingCommandInput,
  DescribeTableReplicaAutoScalingCommandOutput,
} from "./commands/DescribeTableReplicaAutoScalingCommand";
import {
  DescribeTimeToLiveCommandInput,
  DescribeTimeToLiveCommandOutput,
} from "./commands/DescribeTimeToLiveCommand";
import {
  DisableKinesisStreamingDestinationCommandInput,
  DisableKinesisStreamingDestinationCommandOutput,
} from "./commands/DisableKinesisStreamingDestinationCommand";
import {
  EnableKinesisStreamingDestinationCommandInput,
  EnableKinesisStreamingDestinationCommandOutput,
} from "./commands/EnableKinesisStreamingDestinationCommand";
import {
  ExecuteStatementCommandInput,
  ExecuteStatementCommandOutput,
} from "./commands/ExecuteStatementCommand";
import {
  ExecuteTransactionCommandInput,
  ExecuteTransactionCommandOutput,
} from "./commands/ExecuteTransactionCommand";
import {
  ExportTableToPointInTimeCommandInput,
  ExportTableToPointInTimeCommandOutput,
} from "./commands/ExportTableToPointInTimeCommand";
import { GetItemCommandInput, GetItemCommandOutput } from "./commands/GetItemCommand";
import {
  GetResourcePolicyCommandInput,
  GetResourcePolicyCommandOutput,
} from "./commands/GetResourcePolicyCommand";
import { ImportTableCommandInput, ImportTableCommandOutput } from "./commands/ImportTableCommand";
import { ListBackupsCommandInput, ListBackupsCommandOutput } from "./commands/ListBackupsCommand";
import {
  ListContributorInsightsCommandInput,
  ListContributorInsightsCommandOutput,
} from "./commands/ListContributorInsightsCommand";
import { ListExportsCommandInput, ListExportsCommandOutput } from "./commands/ListExportsCommand";
import {
  ListGlobalTablesCommandInput,
  ListGlobalTablesCommandOutput,
} from "./commands/ListGlobalTablesCommand";
import { ListImportsCommandInput, ListImportsCommandOutput } from "./commands/ListImportsCommand";
import { ListTablesCommandInput, ListTablesCommandOutput } from "./commands/ListTablesCommand";
import {
  ListTagsOfResourceCommandInput,
  ListTagsOfResourceCommandOutput,
} from "./commands/ListTagsOfResourceCommand";
import { PutItemCommandInput, PutItemCommandOutput } from "./commands/PutItemCommand";
import {
  PutResourcePolicyCommandInput,
  PutResourcePolicyCommandOutput,
} from "./commands/PutResourcePolicyCommand";
import { QueryCommandInput, QueryCommandOutput } from "./commands/QueryCommand";
import {
  RestoreTableFromBackupCommandInput,
  RestoreTableFromBackupCommandOutput,
} from "./commands/RestoreTableFromBackupCommand";
import {
  RestoreTableToPointInTimeCommandInput,
  RestoreTableToPointInTimeCommandOutput,
} from "./commands/RestoreTableToPointInTimeCommand";
import { ScanCommandInput, ScanCommandOutput } from "./commands/ScanCommand";
import {
  SearchVectorsCommandInput,
  SearchVectorsCommandOutput,
} from "./commands/SearchVectorsCommand";
import { TagResourceCommandInput, TagResourceCommandOutput } from "./commands/TagResourceCommand";
import {
  TransactGetItemsCommandInput,
  TransactGetItemsCommandOutput,
} from "./commands/TransactGetItemsCommand";
import {
  TransactWriteItemsCommandInput,
  TransactWriteItemsCommandOutput,
} from "./commands/TransactWriteItemsCommand";
import {
  UntagResourceCommandInput,
  UntagResourceCommandOutput,
} from "./commands/UntagResourceCommand";
import {
  UpdateContinuousBackupsCommandInput,
  UpdateContinuousBackupsCommandOutput,
} from "./commands/UpdateContinuousBackupsCommand";
import {
  UpdateContributorInsightsCommandInput,
  UpdateContributorInsightsCommandOutput,
} from "./commands/UpdateContributorInsightsCommand";
import {
  UpdateGlobalTableCommandInput,
  UpdateGlobalTableCommandOutput,
} from "./commands/UpdateGlobalTableCommand";
import {
  UpdateGlobalTableSettingsCommandInput,
  UpdateGlobalTableSettingsCommandOutput,
} from "./commands/UpdateGlobalTableSettingsCommand";
import { UpdateItemCommandInput, UpdateItemCommandOutput } from "./commands/UpdateItemCommand";
import {
  UpdateKinesisStreamingDestinationCommandInput,
  UpdateKinesisStreamingDestinationCommandOutput,
} from "./commands/UpdateKinesisStreamingDestinationCommand";
import { UpdateTableCommandInput, UpdateTableCommandOutput } from "./commands/UpdateTableCommand";
import {
  UpdateTableReplicaAutoScalingCommandInput,
  UpdateTableReplicaAutoScalingCommandOutput,
} from "./commands/UpdateTableReplicaAutoScalingCommand";
import {
  UpdateTimeToLiveCommandInput,
  UpdateTimeToLiveCommandOutput,
} from "./commands/UpdateTimeToLiveCommand";
import { DynamoDBClient } from "./DynamoDBClient";
import { ResourceNotFoundException } from "./models/errors";
export interface DynamoDBRequestOptions extends __HttpHandlerOptions {
  metricsRecorder?: __MetricsRecorder<unknown>;
}
export interface DynamoDB {
  batchExecuteStatement(
    args: BatchExecuteStatementCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<BatchExecuteStatementCommandOutput>;
  batchExecuteStatement(
    args: BatchExecuteStatementCommandInput,
    cb: (err: any, data?: BatchExecuteStatementCommandOutput) => void,
  ): void;
  batchExecuteStatement(
    args: BatchExecuteStatementCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: BatchExecuteStatementCommandOutput) => void,
  ): void;
  batchGetItem(
    args: BatchGetItemCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<BatchGetItemCommandOutput>;
  batchGetItem(
    args: BatchGetItemCommandInput,
    cb: (err: any, data?: BatchGetItemCommandOutput) => void,
  ): void;
  batchGetItem(
    args: BatchGetItemCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: BatchGetItemCommandOutput) => void,
  ): void;
  batchWriteItem(
    args: BatchWriteItemCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<BatchWriteItemCommandOutput>;
  batchWriteItem(
    args: BatchWriteItemCommandInput,
    cb: (err: any, data?: BatchWriteItemCommandOutput) => void,
  ): void;
  batchWriteItem(
    args: BatchWriteItemCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: BatchWriteItemCommandOutput) => void,
  ): void;
  createBackup(
    args: CreateBackupCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<CreateBackupCommandOutput>;
  createBackup(
    args: CreateBackupCommandInput,
    cb: (err: any, data?: CreateBackupCommandOutput) => void,
  ): void;
  createBackup(
    args: CreateBackupCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: CreateBackupCommandOutput) => void,
  ): void;
  createGlobalTable(
    args: CreateGlobalTableCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<CreateGlobalTableCommandOutput>;
  createGlobalTable(
    args: CreateGlobalTableCommandInput,
    cb: (err: any, data?: CreateGlobalTableCommandOutput) => void,
  ): void;
  createGlobalTable(
    args: CreateGlobalTableCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: CreateGlobalTableCommandOutput) => void,
  ): void;
  createTable(
    args: CreateTableCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<CreateTableCommandOutput>;
  createTable(
    args: CreateTableCommandInput,
    cb: (err: any, data?: CreateTableCommandOutput) => void,
  ): void;
  createTable(
    args: CreateTableCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: CreateTableCommandOutput) => void,
  ): void;
  deleteBackup(
    args: DeleteBackupCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<DeleteBackupCommandOutput>;
  deleteBackup(
    args: DeleteBackupCommandInput,
    cb: (err: any, data?: DeleteBackupCommandOutput) => void,
  ): void;
  deleteBackup(
    args: DeleteBackupCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: DeleteBackupCommandOutput) => void,
  ): void;
  deleteItem(
    args: DeleteItemCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<DeleteItemCommandOutput>;
  deleteItem(
    args: DeleteItemCommandInput,
    cb: (err: any, data?: DeleteItemCommandOutput) => void,
  ): void;
  deleteItem(
    args: DeleteItemCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: DeleteItemCommandOutput) => void,
  ): void;
  deleteResourcePolicy(
    args: DeleteResourcePolicyCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<DeleteResourcePolicyCommandOutput>;
  deleteResourcePolicy(
    args: DeleteResourcePolicyCommandInput,
    cb: (err: any, data?: DeleteResourcePolicyCommandOutput) => void,
  ): void;
  deleteResourcePolicy(
    args: DeleteResourcePolicyCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: DeleteResourcePolicyCommandOutput) => void,
  ): void;
  deleteTable(
    args: DeleteTableCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<DeleteTableCommandOutput>;
  deleteTable(
    args: DeleteTableCommandInput,
    cb: (err: any, data?: DeleteTableCommandOutput) => void,
  ): void;
  deleteTable(
    args: DeleteTableCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: DeleteTableCommandOutput) => void,
  ): void;
  describeBackup(
    args: DescribeBackupCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<DescribeBackupCommandOutput>;
  describeBackup(
    args: DescribeBackupCommandInput,
    cb: (err: any, data?: DescribeBackupCommandOutput) => void,
  ): void;
  describeBackup(
    args: DescribeBackupCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: DescribeBackupCommandOutput) => void,
  ): void;
  describeContinuousBackups(
    args: DescribeContinuousBackupsCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<DescribeContinuousBackupsCommandOutput>;
  describeContinuousBackups(
    args: DescribeContinuousBackupsCommandInput,
    cb: (err: any, data?: DescribeContinuousBackupsCommandOutput) => void,
  ): void;
  describeContinuousBackups(
    args: DescribeContinuousBackupsCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: DescribeContinuousBackupsCommandOutput) => void,
  ): void;
  describeContributorInsights(
    args: DescribeContributorInsightsCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<DescribeContributorInsightsCommandOutput>;
  describeContributorInsights(
    args: DescribeContributorInsightsCommandInput,
    cb: (err: any, data?: DescribeContributorInsightsCommandOutput) => void,
  ): void;
  describeContributorInsights(
    args: DescribeContributorInsightsCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: DescribeContributorInsightsCommandOutput) => void,
  ): void;
  describeEndpoints(): Promise<DescribeEndpointsCommandOutput>;
  describeEndpoints(
    args: DescribeEndpointsCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<DescribeEndpointsCommandOutput>;
  describeEndpoints(
    args: DescribeEndpointsCommandInput,
    cb: (err: any, data?: DescribeEndpointsCommandOutput) => void,
  ): void;
  describeEndpoints(
    args: DescribeEndpointsCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: DescribeEndpointsCommandOutput) => void,
  ): void;
  describeExport(
    args: DescribeExportCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<DescribeExportCommandOutput>;
  describeExport(
    args: DescribeExportCommandInput,
    cb: (err: any, data?: DescribeExportCommandOutput) => void,
  ): void;
  describeExport(
    args: DescribeExportCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: DescribeExportCommandOutput) => void,
  ): void;
  describeGlobalTable(
    args: DescribeGlobalTableCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<DescribeGlobalTableCommandOutput>;
  describeGlobalTable(
    args: DescribeGlobalTableCommandInput,
    cb: (err: any, data?: DescribeGlobalTableCommandOutput) => void,
  ): void;
  describeGlobalTable(
    args: DescribeGlobalTableCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: DescribeGlobalTableCommandOutput) => void,
  ): void;
  describeGlobalTableSettings(
    args: DescribeGlobalTableSettingsCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<DescribeGlobalTableSettingsCommandOutput>;
  describeGlobalTableSettings(
    args: DescribeGlobalTableSettingsCommandInput,
    cb: (err: any, data?: DescribeGlobalTableSettingsCommandOutput) => void,
  ): void;
  describeGlobalTableSettings(
    args: DescribeGlobalTableSettingsCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: DescribeGlobalTableSettingsCommandOutput) => void,
  ): void;
  describeImport(
    args: DescribeImportCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<DescribeImportCommandOutput>;
  describeImport(
    args: DescribeImportCommandInput,
    cb: (err: any, data?: DescribeImportCommandOutput) => void,
  ): void;
  describeImport(
    args: DescribeImportCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: DescribeImportCommandOutput) => void,
  ): void;
  describeKinesisStreamingDestination(
    args: DescribeKinesisStreamingDestinationCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<DescribeKinesisStreamingDestinationCommandOutput>;
  describeKinesisStreamingDestination(
    args: DescribeKinesisStreamingDestinationCommandInput,
    cb: (err: any, data?: DescribeKinesisStreamingDestinationCommandOutput) => void,
  ): void;
  describeKinesisStreamingDestination(
    args: DescribeKinesisStreamingDestinationCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: DescribeKinesisStreamingDestinationCommandOutput) => void,
  ): void;
  describeLimits(): Promise<DescribeLimitsCommandOutput>;
  describeLimits(
    args: DescribeLimitsCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<DescribeLimitsCommandOutput>;
  describeLimits(
    args: DescribeLimitsCommandInput,
    cb: (err: any, data?: DescribeLimitsCommandOutput) => void,
  ): void;
  describeLimits(
    args: DescribeLimitsCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: DescribeLimitsCommandOutput) => void,
  ): void;
  describeTable(
    args: DescribeTableCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<DescribeTableCommandOutput>;
  describeTable(
    args: DescribeTableCommandInput,
    cb: (err: any, data?: DescribeTableCommandOutput) => void,
  ): void;
  describeTable(
    args: DescribeTableCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: DescribeTableCommandOutput) => void,
  ): void;
  describeTableReplicaAutoScaling(
    args: DescribeTableReplicaAutoScalingCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<DescribeTableReplicaAutoScalingCommandOutput>;
  describeTableReplicaAutoScaling(
    args: DescribeTableReplicaAutoScalingCommandInput,
    cb: (err: any, data?: DescribeTableReplicaAutoScalingCommandOutput) => void,
  ): void;
  describeTableReplicaAutoScaling(
    args: DescribeTableReplicaAutoScalingCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: DescribeTableReplicaAutoScalingCommandOutput) => void,
  ): void;
  describeTimeToLive(
    args: DescribeTimeToLiveCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<DescribeTimeToLiveCommandOutput>;
  describeTimeToLive(
    args: DescribeTimeToLiveCommandInput,
    cb: (err: any, data?: DescribeTimeToLiveCommandOutput) => void,
  ): void;
  describeTimeToLive(
    args: DescribeTimeToLiveCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: DescribeTimeToLiveCommandOutput) => void,
  ): void;
  disableKinesisStreamingDestination(
    args: DisableKinesisStreamingDestinationCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<DisableKinesisStreamingDestinationCommandOutput>;
  disableKinesisStreamingDestination(
    args: DisableKinesisStreamingDestinationCommandInput,
    cb: (err: any, data?: DisableKinesisStreamingDestinationCommandOutput) => void,
  ): void;
  disableKinesisStreamingDestination(
    args: DisableKinesisStreamingDestinationCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: DisableKinesisStreamingDestinationCommandOutput) => void,
  ): void;
  enableKinesisStreamingDestination(
    args: EnableKinesisStreamingDestinationCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<EnableKinesisStreamingDestinationCommandOutput>;
  enableKinesisStreamingDestination(
    args: EnableKinesisStreamingDestinationCommandInput,
    cb: (err: any, data?: EnableKinesisStreamingDestinationCommandOutput) => void,
  ): void;
  enableKinesisStreamingDestination(
    args: EnableKinesisStreamingDestinationCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: EnableKinesisStreamingDestinationCommandOutput) => void,
  ): void;
  executeStatement(
    args: ExecuteStatementCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<ExecuteStatementCommandOutput>;
  executeStatement(
    args: ExecuteStatementCommandInput,
    cb: (err: any, data?: ExecuteStatementCommandOutput) => void,
  ): void;
  executeStatement(
    args: ExecuteStatementCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: ExecuteStatementCommandOutput) => void,
  ): void;
  executeTransaction(
    args: ExecuteTransactionCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<ExecuteTransactionCommandOutput>;
  executeTransaction(
    args: ExecuteTransactionCommandInput,
    cb: (err: any, data?: ExecuteTransactionCommandOutput) => void,
  ): void;
  executeTransaction(
    args: ExecuteTransactionCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: ExecuteTransactionCommandOutput) => void,
  ): void;
  exportTableToPointInTime(
    args: ExportTableToPointInTimeCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<ExportTableToPointInTimeCommandOutput>;
  exportTableToPointInTime(
    args: ExportTableToPointInTimeCommandInput,
    cb: (err: any, data?: ExportTableToPointInTimeCommandOutput) => void,
  ): void;
  exportTableToPointInTime(
    args: ExportTableToPointInTimeCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: ExportTableToPointInTimeCommandOutput) => void,
  ): void;
  getItem(
    args: GetItemCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<GetItemCommandOutput>;
  getItem(args: GetItemCommandInput, cb: (err: any, data?: GetItemCommandOutput) => void): void;
  getItem(
    args: GetItemCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: GetItemCommandOutput) => void,
  ): void;
  getResourcePolicy(
    args: GetResourcePolicyCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<GetResourcePolicyCommandOutput>;
  getResourcePolicy(
    args: GetResourcePolicyCommandInput,
    cb: (err: any, data?: GetResourcePolicyCommandOutput) => void,
  ): void;
  getResourcePolicy(
    args: GetResourcePolicyCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: GetResourcePolicyCommandOutput) => void,
  ): void;
  importTable(
    args: ImportTableCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<ImportTableCommandOutput>;
  importTable(
    args: ImportTableCommandInput,
    cb: (err: any, data?: ImportTableCommandOutput) => void,
  ): void;
  importTable(
    args: ImportTableCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: ImportTableCommandOutput) => void,
  ): void;
  listBackups(): Promise<ListBackupsCommandOutput>;
  listBackups(
    args: ListBackupsCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<ListBackupsCommandOutput>;
  listBackups(
    args: ListBackupsCommandInput,
    cb: (err: any, data?: ListBackupsCommandOutput) => void,
  ): void;
  listBackups(
    args: ListBackupsCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: ListBackupsCommandOutput) => void,
  ): void;
  listContributorInsights(): Promise<ListContributorInsightsCommandOutput>;
  listContributorInsights(
    args: ListContributorInsightsCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<ListContributorInsightsCommandOutput>;
  listContributorInsights(
    args: ListContributorInsightsCommandInput,
    cb: (err: any, data?: ListContributorInsightsCommandOutput) => void,
  ): void;
  listContributorInsights(
    args: ListContributorInsightsCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: ListContributorInsightsCommandOutput) => void,
  ): void;
  listExports(): Promise<ListExportsCommandOutput>;
  listExports(
    args: ListExportsCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<ListExportsCommandOutput>;
  listExports(
    args: ListExportsCommandInput,
    cb: (err: any, data?: ListExportsCommandOutput) => void,
  ): void;
  listExports(
    args: ListExportsCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: ListExportsCommandOutput) => void,
  ): void;
  listGlobalTables(): Promise<ListGlobalTablesCommandOutput>;
  listGlobalTables(
    args: ListGlobalTablesCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<ListGlobalTablesCommandOutput>;
  listGlobalTables(
    args: ListGlobalTablesCommandInput,
    cb: (err: any, data?: ListGlobalTablesCommandOutput) => void,
  ): void;
  listGlobalTables(
    args: ListGlobalTablesCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: ListGlobalTablesCommandOutput) => void,
  ): void;
  listImports(): Promise<ListImportsCommandOutput>;
  listImports(
    args: ListImportsCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<ListImportsCommandOutput>;
  listImports(
    args: ListImportsCommandInput,
    cb: (err: any, data?: ListImportsCommandOutput) => void,
  ): void;
  listImports(
    args: ListImportsCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: ListImportsCommandOutput) => void,
  ): void;
  listTables(): Promise<ListTablesCommandOutput>;
  listTables(
    args: ListTablesCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<ListTablesCommandOutput>;
  listTables(
    args: ListTablesCommandInput,
    cb: (err: any, data?: ListTablesCommandOutput) => void,
  ): void;
  listTables(
    args: ListTablesCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: ListTablesCommandOutput) => void,
  ): void;
  listTagsOfResource(
    args: ListTagsOfResourceCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<ListTagsOfResourceCommandOutput>;
  listTagsOfResource(
    args: ListTagsOfResourceCommandInput,
    cb: (err: any, data?: ListTagsOfResourceCommandOutput) => void,
  ): void;
  listTagsOfResource(
    args: ListTagsOfResourceCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: ListTagsOfResourceCommandOutput) => void,
  ): void;
  putItem(
    args: PutItemCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<PutItemCommandOutput>;
  putItem(args: PutItemCommandInput, cb: (err: any, data?: PutItemCommandOutput) => void): void;
  putItem(
    args: PutItemCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: PutItemCommandOutput) => void,
  ): void;
  putResourcePolicy(
    args: PutResourcePolicyCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<PutResourcePolicyCommandOutput>;
  putResourcePolicy(
    args: PutResourcePolicyCommandInput,
    cb: (err: any, data?: PutResourcePolicyCommandOutput) => void,
  ): void;
  putResourcePolicy(
    args: PutResourcePolicyCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: PutResourcePolicyCommandOutput) => void,
  ): void;
  query(args: QueryCommandInput, options?: DynamoDBRequestOptions): Promise<QueryCommandOutput>;
  query(args: QueryCommandInput, cb: (err: any, data?: QueryCommandOutput) => void): void;
  query(
    args: QueryCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: QueryCommandOutput) => void,
  ): void;
  restoreTableFromBackup(
    args: RestoreTableFromBackupCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<RestoreTableFromBackupCommandOutput>;
  restoreTableFromBackup(
    args: RestoreTableFromBackupCommandInput,
    cb: (err: any, data?: RestoreTableFromBackupCommandOutput) => void,
  ): void;
  restoreTableFromBackup(
    args: RestoreTableFromBackupCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: RestoreTableFromBackupCommandOutput) => void,
  ): void;
  restoreTableToPointInTime(
    args: RestoreTableToPointInTimeCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<RestoreTableToPointInTimeCommandOutput>;
  restoreTableToPointInTime(
    args: RestoreTableToPointInTimeCommandInput,
    cb: (err: any, data?: RestoreTableToPointInTimeCommandOutput) => void,
  ): void;
  restoreTableToPointInTime(
    args: RestoreTableToPointInTimeCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: RestoreTableToPointInTimeCommandOutput) => void,
  ): void;
  scan(args: ScanCommandInput, options?: DynamoDBRequestOptions): Promise<ScanCommandOutput>;
  scan(args: ScanCommandInput, cb: (err: any, data?: ScanCommandOutput) => void): void;
  scan(
    args: ScanCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: ScanCommandOutput) => void,
  ): void;
  searchVectors(
    args: SearchVectorsCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<SearchVectorsCommandOutput>;
  searchVectors(
    args: SearchVectorsCommandInput,
    cb: (err: any, data?: SearchVectorsCommandOutput) => void,
  ): void;
  searchVectors(
    args: SearchVectorsCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: SearchVectorsCommandOutput) => void,
  ): void;
  tagResource(
    args: TagResourceCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<TagResourceCommandOutput>;
  tagResource(
    args: TagResourceCommandInput,
    cb: (err: any, data?: TagResourceCommandOutput) => void,
  ): void;
  tagResource(
    args: TagResourceCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: TagResourceCommandOutput) => void,
  ): void;
  transactGetItems(
    args: TransactGetItemsCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<TransactGetItemsCommandOutput>;
  transactGetItems(
    args: TransactGetItemsCommandInput,
    cb: (err: any, data?: TransactGetItemsCommandOutput) => void,
  ): void;
  transactGetItems(
    args: TransactGetItemsCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: TransactGetItemsCommandOutput) => void,
  ): void;
  transactWriteItems(
    args: TransactWriteItemsCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<TransactWriteItemsCommandOutput>;
  transactWriteItems(
    args: TransactWriteItemsCommandInput,
    cb: (err: any, data?: TransactWriteItemsCommandOutput) => void,
  ): void;
  transactWriteItems(
    args: TransactWriteItemsCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: TransactWriteItemsCommandOutput) => void,
  ): void;
  untagResource(
    args: UntagResourceCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<UntagResourceCommandOutput>;
  untagResource(
    args: UntagResourceCommandInput,
    cb: (err: any, data?: UntagResourceCommandOutput) => void,
  ): void;
  untagResource(
    args: UntagResourceCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: UntagResourceCommandOutput) => void,
  ): void;
  updateContinuousBackups(
    args: UpdateContinuousBackupsCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<UpdateContinuousBackupsCommandOutput>;
  updateContinuousBackups(
    args: UpdateContinuousBackupsCommandInput,
    cb: (err: any, data?: UpdateContinuousBackupsCommandOutput) => void,
  ): void;
  updateContinuousBackups(
    args: UpdateContinuousBackupsCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: UpdateContinuousBackupsCommandOutput) => void,
  ): void;
  updateContributorInsights(
    args: UpdateContributorInsightsCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<UpdateContributorInsightsCommandOutput>;
  updateContributorInsights(
    args: UpdateContributorInsightsCommandInput,
    cb: (err: any, data?: UpdateContributorInsightsCommandOutput) => void,
  ): void;
  updateContributorInsights(
    args: UpdateContributorInsightsCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: UpdateContributorInsightsCommandOutput) => void,
  ): void;
  updateGlobalTable(
    args: UpdateGlobalTableCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<UpdateGlobalTableCommandOutput>;
  updateGlobalTable(
    args: UpdateGlobalTableCommandInput,
    cb: (err: any, data?: UpdateGlobalTableCommandOutput) => void,
  ): void;
  updateGlobalTable(
    args: UpdateGlobalTableCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: UpdateGlobalTableCommandOutput) => void,
  ): void;
  updateGlobalTableSettings(
    args: UpdateGlobalTableSettingsCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<UpdateGlobalTableSettingsCommandOutput>;
  updateGlobalTableSettings(
    args: UpdateGlobalTableSettingsCommandInput,
    cb: (err: any, data?: UpdateGlobalTableSettingsCommandOutput) => void,
  ): void;
  updateGlobalTableSettings(
    args: UpdateGlobalTableSettingsCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: UpdateGlobalTableSettingsCommandOutput) => void,
  ): void;
  updateItem(
    args: UpdateItemCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<UpdateItemCommandOutput>;
  updateItem(
    args: UpdateItemCommandInput,
    cb: (err: any, data?: UpdateItemCommandOutput) => void,
  ): void;
  updateItem(
    args: UpdateItemCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: UpdateItemCommandOutput) => void,
  ): void;
  updateKinesisStreamingDestination(
    args: UpdateKinesisStreamingDestinationCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<UpdateKinesisStreamingDestinationCommandOutput>;
  updateKinesisStreamingDestination(
    args: UpdateKinesisStreamingDestinationCommandInput,
    cb: (err: any, data?: UpdateKinesisStreamingDestinationCommandOutput) => void,
  ): void;
  updateKinesisStreamingDestination(
    args: UpdateKinesisStreamingDestinationCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: UpdateKinesisStreamingDestinationCommandOutput) => void,
  ): void;
  updateTable(
    args: UpdateTableCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<UpdateTableCommandOutput>;
  updateTable(
    args: UpdateTableCommandInput,
    cb: (err: any, data?: UpdateTableCommandOutput) => void,
  ): void;
  updateTable(
    args: UpdateTableCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: UpdateTableCommandOutput) => void,
  ): void;
  updateTableReplicaAutoScaling(
    args: UpdateTableReplicaAutoScalingCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<UpdateTableReplicaAutoScalingCommandOutput>;
  updateTableReplicaAutoScaling(
    args: UpdateTableReplicaAutoScalingCommandInput,
    cb: (err: any, data?: UpdateTableReplicaAutoScalingCommandOutput) => void,
  ): void;
  updateTableReplicaAutoScaling(
    args: UpdateTableReplicaAutoScalingCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: UpdateTableReplicaAutoScalingCommandOutput) => void,
  ): void;
  updateTimeToLive(
    args: UpdateTimeToLiveCommandInput,
    options?: DynamoDBRequestOptions,
  ): Promise<UpdateTimeToLiveCommandOutput>;
  updateTimeToLive(
    args: UpdateTimeToLiveCommandInput,
    cb: (err: any, data?: UpdateTimeToLiveCommandOutput) => void,
  ): void;
  updateTimeToLive(
    args: UpdateTimeToLiveCommandInput,
    options: DynamoDBRequestOptions,
    cb: (err: any, data?: UpdateTimeToLiveCommandOutput) => void,
  ): void;
  paginateListContributorInsights(
    args?: ListContributorInsightsCommandInput,
    paginationConfig?: Pick<
      PaginationConfiguration,
      Exclude<keyof PaginationConfiguration, "client">
    >,
  ): Paginator<ListContributorInsightsCommandOutput>;
  paginateListExports(
    args?: ListExportsCommandInput,
    paginationConfig?: Pick<
      PaginationConfiguration,
      Exclude<keyof PaginationConfiguration, "client">
    >,
  ): Paginator<ListExportsCommandOutput>;
  paginateListImports(
    args?: ListImportsCommandInput,
    paginationConfig?: Pick<
      PaginationConfiguration,
      Exclude<keyof PaginationConfiguration, "client">
    >,
  ): Paginator<ListImportsCommandOutput>;
  paginateListTables(
    args?: ListTablesCommandInput,
    paginationConfig?: Pick<
      PaginationConfiguration,
      Exclude<keyof PaginationConfiguration, "client">
    >,
  ): Paginator<ListTablesCommandOutput>;
  paginateQuery(
    args: QueryCommandInput,
    paginationConfig?: Pick<
      PaginationConfiguration,
      Exclude<keyof PaginationConfiguration, "client">
    >,
  ): Paginator<QueryCommandOutput>;
  paginateScan(
    args: ScanCommandInput,
    paginationConfig?: Pick<
      PaginationConfiguration,
      Exclude<keyof PaginationConfiguration, "client">
    >,
  ): Paginator<ScanCommandOutput>;
  waitUntilContributorInsightsEnabled(
    args: DescribeContributorInsightsCommandInput,
    waiterConfig:
      | number
      | Pick<WaiterConfiguration<DynamoDB>, Exclude<keyof WaiterConfiguration<DynamoDB>, "client">>,
  ): Promise<WaiterResult<DescribeContributorInsightsCommandOutput>>;
  waitUntilExportCompleted(
    args: DescribeExportCommandInput,
    waiterConfig:
      | number
      | Pick<WaiterConfiguration<DynamoDB>, Exclude<keyof WaiterConfiguration<DynamoDB>, "client">>,
  ): Promise<WaiterResult<DescribeExportCommandOutput>>;
  waitUntilImportCompleted(
    args: DescribeImportCommandInput,
    waiterConfig:
      | number
      | Pick<WaiterConfiguration<DynamoDB>, Exclude<keyof WaiterConfiguration<DynamoDB>, "client">>,
  ): Promise<WaiterResult<DescribeImportCommandOutput>>;
  waitUntilKinesisStreamingDestinationActive(
    args: DescribeKinesisStreamingDestinationCommandInput,
    waiterConfig:
      | number
      | Pick<WaiterConfiguration<DynamoDB>, Exclude<keyof WaiterConfiguration<DynamoDB>, "client">>,
  ): Promise<WaiterResult<DescribeKinesisStreamingDestinationCommandOutput>>;
  waitUntilTableExists(
    args: DescribeTableCommandInput,
    waiterConfig:
      | number
      | Pick<WaiterConfiguration<DynamoDB>, Exclude<keyof WaiterConfiguration<DynamoDB>, "client">>,
  ): Promise<WaiterResult<DescribeTableCommandOutput>>;
  waitUntilTableNotExists(
    args: DescribeTableCommandInput,
    waiterConfig:
      | number
      | Pick<WaiterConfiguration<DynamoDB>, Exclude<keyof WaiterConfiguration<DynamoDB>, "client">>,
  ): Promise<WaiterResult<ResourceNotFoundException>>;
}
export declare class DynamoDB extends DynamoDBClient implements DynamoDB {}
